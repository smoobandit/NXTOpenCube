package com.example.firstapp;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityMain extends Activity {
	Camera camera;
	PictureCallback rawCallback;
	ShutterCallback shutterCallback;
	PictureCallback jpegCallback;
	
	int photocount = 0;
	char[] filenames = {'U','D','L','R','B','F'};
	
	final Context context = this;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		NxtMain.connectionEstablished = false;
		NxtMain.lifterStatus = 0;
		NxtMain.stop = false;
		NxtMain.starttime = 0;
		NxtMain.runtime = false;
		
		setContentView(R.layout.activity_main);
		
		Toast.makeText(getApplicationContext(), getString(R.string.app_name), Toast.LENGTH_LONG).show();
			
		camera = Camera.open();
		//camera.unlock();
   		
		Camera.Parameters param;
		param = camera.getParameters();

		// modify parameter
		param.setPreviewSize(352, 288);
		param.setFlashMode(Parameters.FLASH_MODE_ON);
		//param.setFlashMode(Parameters.FLASH_MODE_TORCH);
		param.setFocusMode(Parameters.FOCUS_MODE_MACRO);
		param.setWhiteBalance(Parameters.WHITE_BALANCE_FLUORESCENT);
		param.setSceneMode(Parameters.SCENE_MODE_PARTY);
		//param.setExposureCompensation(0);
		//param.setAutoExposureLock(true);
		camera.setParameters(param);
		camera.setDisplayOrientation(90);
		camera.startPreview();
				
		jpegCallback = new PictureCallback() {
			public void onPictureTaken(byte[] data, Camera camera) {
				FileOutputStream outStream = null;
				try {
					outStream = new FileOutputStream(NxtMain.picpath +  filenames[photocount] + ".jpg");
					photocount++;
					outStream.write(data);
					outStream.close();
					Toast.makeText(getApplicationContext(), getString(R.string.toast_picsaved) + ": " + filenames[photocount-1] + " (" + data.length + ").", Toast.LENGTH_SHORT).show();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} finally {}
				camera.stopPreview();
				
				camera.startPreview();
				switch (photocount) {
					case 1: //U -> D (Yellow -> White)
						NxtMain.connNxtSM2.sendCommand("TURN(NS,2,-2)");
						break;
					case 2: //D -> L (White -> Red)
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(EW,1,1)");
						NxtMain.connNxtSM1.sendCommand("OPEN(NS,1,1)");
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						break;
					case 3: //L -> R (Red -> Orange)
						NxtMain.connNxtSM1.sendCommand("TURN(EW,-2,2)");
						break;
					case 4: //R -> B (Orange -> Blue)
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(NS,1,1)");
						NxtMain.connNxtSM1.sendCommand("OPEN(EW,1,1)");
						NxtMain.connNxtSM1.sendCommand("TURN(EW,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(EW,1,1)");
						NxtMain.connNxtSM1.sendCommand("OPEN(NS,1,1)");
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("TURN(EW,-1,1)");
						break;
					case 5: //B -> F (Blue -> Green)
						NxtMain.connNxtSM1.sendCommand("TURN(EW,-2,2)");
						break;
					case 6:
						NxtMain.connNxtSM1.sendCommand("TURN(EW,1,-1)");
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(NS,1,1)");
						NxtMain.connNxtSM1.sendCommand("OPEN(EW,1,1)");
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(EW,1,1)");
						NxtMain.connNxtSM1.sendCommand("OPEN(NS,1,1)");
						NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,1)");
						NxtMain.connNxtSM1.sendCommand("CLOSE(NS,1,1)");
						break;
				}
				if (photocount < 6) { camera.takePicture(null, null, jpegCallback); } else {
					camera.lock();
					new Thread(new Runnable() {
			   			public void run() {
			   				lastStep();
			   			}
					}).start();
				}
			}
		};
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
		final Button buttonStart = (Button) findViewById(R.id.buttonStart);
		final Button buttonStop = (Button) findViewById(R.id.buttonStop);
					
		Typeface tf = Typeface.createFromAsset(getAssets(),"fonts/ericssonga628.ttf"); 
		TextView tv = (TextView) findViewById(R.id.textViewTime);
        tv.setTypeface(tf);
		
       
        
        //strings holen
   		SharedPreferences settings = getSharedPreferences("Settings", 0);
   		NxtMain.nxtName1 = settings.getString("NxtName1", getString(R.string.value_nxtname1)).toString();
   		NxtMain.nxtName2 = settings.getString("NxtName2", getString(R.string.value_nxtname2)).toString();
   		NxtMain.progName = settings.getString("ProgName", getString(R.string.value_progname)).toString();
   		NxtMain.waitOpen = Integer.parseInt(settings.getString("WaitOpen", getString(R.string.value_waitopen)).toString());
   		NxtMain.waitClose = Integer.parseInt(settings.getString("WaitClose", getString(R.string.value_waitclose)).toString());
   		NxtMain.waitTurn = Integer.parseInt(settings.getString("WaitTurn", getString(R.string.value_waitturn)).toString());
   		NxtMain.waitDoubleTurn = Integer.parseInt(settings.getString("WaitDoubleTurn", getString(R.string.value_waitdoubleturn)).toString());
   	   	
   		buttonStart.setEnabled(true);	
        buttonStop.setEnabled(false);
        
        if (NxtMain.connectionEstablished) {
        	buttonStart.setText(getString(R.string.main_buttonstart1));
        }  else {
        	buttonStart.setText(getString(R.string.main_buttonstart2));
        } 
        
		buttonStop.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
				final Button buttonStart = (Button) findViewById(R.id.buttonStart);
				final Button buttonStop = (Button) findViewById(R.id.buttonStop);
				final TextView textViewStatus = (TextView) findViewById(R.id.textViewStatus);
		   		
		   		NxtMain.stop = true;
		   		NxtMain.lifterStatus = 0;
				NxtMain.starttime = 0;
				NxtMain.runtime = false;
				NxtMain.connNxtSM1.stopProgram();
				NxtMain.connNxtSM2.stopProgram();
				
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						buttonStart.setEnabled(false);
						buttonStop.setEnabled(false);
						textViewStatus.setText(textViewStatus.getText() + "\r\n" + getString(R.string.status_canceled) + "\r\n");
					}
				});
				
		   	}
		});
				
		buttonStart.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		   		if (NxtMain.connectionEstablished) {
		   			if (NxtMain.lifterStatus == 0) {
				   		AlertDialog.Builder alertDialogBuilder4 = new AlertDialog.Builder(context);
						alertDialogBuilder4
							.setTitle(getString(R.string.dialog_cubetitle))
							.setMessage(getString(R.string.dialog_lifter))
							.setCancelable(false)
							.setNegativeButton(getString(R.string.dialog_lifterbottom),new DialogInterface.OnClickListener() {
			    				public void onClick(DialogInterface dialog,int id) { NxtMain.lifterStatus = 0; dialog.cancel(); startNxtMachine(); }
			    			})
							.setPositiveButton(getString(R.string.dialog_liftertop),new DialogInterface.OnClickListener() {
			    				public void onClick(DialogInterface dialog,int id) { NxtMain.lifterStatus = 2; dialog.cancel(); startNxtMachine();}
			    			});
						AlertDialog alert4 = alertDialogBuilder4.create();
						alert4.show();
			   		} else { startNxtMachine(); }
		   		} else {
		   			Intent nextScreen = new Intent(getApplicationContext(), ActivityInit.class);
					startActivity(nextScreen);
		   		}
		   	}
		});
	}
	
	public void startNxtMachine() {
		new Thread(new Runnable() {
	   			public void run() {
	   				firstStep();
	   			}
		}).start();
			
		new Thread(new Runnable() {
	   		public void run() {
	   				printTime();
	   		}
		}).start();
	}
	
	public void printTime() {
		final TextView textViewTime = (TextView) findViewById(R.id.textViewTime);
		final ScrollView scrollViewStatus = (ScrollView) findViewById(R.id.scrollViewStatus);
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				textViewTime.setText("0:00.00");
			}
		});
		while (!NxtMain.runtime) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					scrollViewStatus.fullScroll(ScrollView.FOCUS_DOWN);
				}
			});
			try{ Thread.sleep(200); } catch(InterruptedException sleepException){ }
		}
		NxtMain.starttime = System.currentTimeMillis();
		while (NxtMain.runtime) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					SimpleDateFormat sdf = new SimpleDateFormat("mm:ss.SS");
					Date d = new Date(System.currentTimeMillis() - NxtMain.starttime);
					String x = sdf.format(d) + "0000";
					
					textViewTime.setText(x.substring(1, 8));
					scrollViewStatus.fullScroll(ScrollView.FOCUS_DOWN);
				}
			});
			try{ Thread.sleep(20); } catch(InterruptedException sleepException){ }
		}
		while (!NxtMain.runtime) {
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					scrollViewStatus.fullScroll(ScrollView.FOCUS_DOWN);
				}
			});
			try{ Thread.sleep(200); } catch(InterruptedException sleepException){ }
		}
	}
	
	public void programCanceled() {
		final Button buttonStart = (Button) findViewById(R.id.buttonStart);
		
		NxtMain.stop = false;
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				buttonStart.setEnabled(true);
			}
		});
	}
	
	public void firstStep() {
		final Button buttonStart = (Button) findViewById(R.id.buttonStart);
		final Button buttonStop = (Button) findViewById(R.id.buttonStop);
		final TextView textViewStatus = (TextView) findViewById(R.id.textViewStatus);
		
		if (NxtMain.stop) { programCanceled(); return; }
		
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				buttonStart.setEnabled(false);
				buttonStop.setEnabled(true);
				textViewStatus.setText(getString(R.string.status_start) + "\r\n");
			}
		});

		//set speed
		NxtMain.connNxtSM1.sendCommand("SETWAIT(OPEN," + NxtMain.waitOpen + ")");
   		NxtMain.connNxtSM1.sendCommand("SETWAIT(CLOSE," + NxtMain.waitClose + ")");
  		NxtMain.connNxtSM1.sendCommand("SETWAIT(TURN,300)");
   		NxtMain.connNxtSM1.sendCommand("SETWAIT(DOUBLETURN,600)");
   		NxtMain.connNxtSM2.sendCommand("SETWAIT(TURN,300)");
   		NxtMain.connNxtSM2.sendCommand("SETWAIT(DOUBLETURN,600)");
				
		if (NxtMain.lifterStatus == 0) {
			if (NxtMain.stop) { programCanceled(); return; }
			
			NxtMain.connNxtSM1.sendCommand("LIFTERINIT()"); 
			NxtMain.lifterStatus = 1;
			
			if (NxtMain.stop) { programCanceled(); return; }
			
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_lifterinit) +"\r\n");
				}
			});
		}
		
		if (NxtMain.lifterStatus == 1) {
			
			if (NxtMain.stop) { programCanceled(); return; }
			
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_lifterup) + "\r\n");
				}
			});
			NxtMain.connNxtSM1.sendCommand("OPEN(NS,1,1)");
	   		NxtMain.connNxtSM1.sendCommand("OPEN(EW,1,1)");
	   		NxtMain.connNxtSM1.sendCommand("LIFT(24)");
	   		NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,-1)");
	   		NxtMain.lifterStatus = 2;
		}
		
		if (NxtMain.lifterStatus == 2) {
			
			if (NxtMain.stop) { programCanceled(); return; }
			
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					AlertDialog.Builder alertDialogBuilder3 = new AlertDialog.Builder(context);
					alertDialogBuilder3
						.setTitle(getString(R.string.dialog_cubetitle))
						.setMessage(getString(R.string.dialog_cubetext))
						.setCancelable(false)
						.setPositiveButton(getString(R.string.dialog_ok),new DialogInterface.OnClickListener() {
		    				public void onClick(DialogInterface dialog,int id) { 
		    					dialog.cancel(); 
		    					new Thread(new Runnable() {
			    		   			public void run() {
			    		   				startSolve();
			    		   			}
			    				}).start();
		    				}
		    			});
					AlertDialog alert3 = alertDialogBuilder3.create();
					alert3.show();
				}
			});
			NxtMain.connNxtSM1.sendCommand("ALERT(WUERFEL,1,100)");
		}
	}
	
	public void startSolve() {
		final TextView textViewStatus = (TextView) findViewById(R.id.textViewStatus);
		final ScrollView scrollViewStatus = (ScrollView) findViewById(R.id.scrollViewStatus);
		
		if (NxtMain.stop) { programCanceled(); return; }
		
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_takecube) + "\r\n");
			}
		});
		
		NxtMain.connNxtSM1.sendCommand("LIFT(-13)");
   		NxtMain.connNxtSM1.sendCommand("CLOSE(NS,1,1)");
  		NxtMain.connNxtSM1.sendCommand("LIFT(-11)");
   		NxtMain.connNxtSM1.sendCommand("TURN(EW,-1,1)");
   		NxtMain.lifterStatus = 0;
		
   		if (NxtMain.stop) { programCanceled(); return; }
   		
   		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_startposition) + "\r\n");
			}
		});
   		
   		//make photos
   		photocount = 0;
		camera.takePicture(null, null, jpegCallback);
	}
	
	public void lastStep() {
		final Button buttonStart = (Button) findViewById(R.id.buttonStart);
		final Button buttonStop = (Button) findViewById(R.id.buttonStop);
		final TextView textViewStatus = (TextView) findViewById(R.id.textViewStatus);
		
		if (NxtMain.stop) { programCanceled(); return; }
		
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_photossaved) + "\r\n");
			}
		});
				
		//detect colors
   		NxtColorDetection colordetection = new NxtColorDetection();
		NxtMain.cubeDefinition = colordetection.getCube(NxtMain.picpath, true);
		
		if (NxtMain.stop) { programCanceled(); return; }
		
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				textViewStatus.setText(textViewStatus.getText() + "\r\n" + getString(R.string.status_colorsdetected) + "\r\n");
				textViewStatus.setText(textViewStatus.getText() + NxtMain.cubeDefinition + "\r\n");
			}
		});
		
		if (NxtMain.cubeDefinition != "UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB") {
			//solve cube
			CsSearch search = new CsSearch();
			NxtMain.cubeSolve = search.solution(NxtMain.cubeDefinition, 21, 100, 0, 0);
			
			if (NxtMain.cubeSolve.substring(0, 1).equals("E")) {
				if (NxtMain.stop) { programCanceled(); return; }
				
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						textViewStatus.setText(textViewStatus.getText() + "\r\n" + getString(R.string.status_cubeerror)+ "\r\n");
						textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_cubeerrortext)+ "\r\n");
					}
				});
				
				//evt turn 
			} else {
				if (NxtMain.stop) { programCanceled(); return; }
				
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						textViewStatus.setText(textViewStatus.getText() + "\r\n" + getString(R.string.status_cubesolved) + "\r\n");
						textViewStatus.setText(textViewStatus.getText() + NxtMain.cubeSolve + "\r\n");
					}
				});
				//set speed
				NxtMain.connNxtSM1.sendCommand("SETWAIT(OPEN," + NxtMain.waitOpen + ")");
		   		NxtMain.connNxtSM1.sendCommand("SETWAIT(CLOSE," + NxtMain.waitClose + ")");
		  		NxtMain.connNxtSM1.sendCommand("SETWAIT(TURN," + NxtMain.waitTurn + ")");
		   		NxtMain.connNxtSM1.sendCommand("SETWAIT(DOUBLETURN," + NxtMain.waitDoubleTurn + ")");
		   		NxtMain.connNxtSM2.sendCommand("SETWAIT(TURN," + NxtMain.waitTurn + ")");
		   		NxtMain.connNxtSM2.sendCommand("SETWAIT(DOUBLETURN," + NxtMain.waitDoubleTurn + ")");
				
		   		if (NxtMain.stop) { programCanceled(); return; }
		   		
				//move cube
				NxtMain.runtime = true;
				NxtMachine machine = new NxtMachine();
		   		machine.moveCube(NxtMain.cubeSolve);
		   		NxtMain.runtime = false;
		   		runOnUiThread(new Runnable() {
					@Override
					public void run() {
						textViewStatus.setText(textViewStatus.getText() + "\r\n" + getString(R.string.status_cubemoved) + "\r\n");
					}
				});
	   		
			}
		}
   		//raise cube
   		NxtMain.connNxtSM1.sendCommand("LIFT(10)");
   		NxtMain.connNxtSM1.sendCommand("OPEN(NS,1,1)");
   		NxtMain.connNxtSM1.sendCommand("OPEN(EW,1,1)");
   		NxtMain.connNxtSM1.sendCommand("LIFT(14)");
   		NxtMain.connNxtSM2.sendCommand("TURN(NS,-1,-1)");
   		NxtMain.lifterStatus = 2;
   		
   		if (NxtMain.stop) { programCanceled(); return; }
   		
   		//finish
   		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				buttonStop.setEnabled(false);
		   		buttonStart.setEnabled(true);
		   		textViewStatus.setText(textViewStatus.getText() + getString(R.string.status_finished) + "\r\n");
			}
		});
	}

	
	@Override
    public void onDestroy() {
        super.onDestroy();
        camera.release();
        Toast.makeText(getApplicationContext(),"Programm beendet", Toast.LENGTH_SHORT).show();
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);	
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_menu) {
			return true;
		}
		if (id == R.id.menuitem_init) {
			Intent nextScreen = new Intent(getApplicationContext(), ActivityInit.class);
			startActivity(nextScreen);
			return true;
		}
		if (id == R.id.menuitem_settings) {
			Intent nextScreen = new Intent(getApplicationContext(), ActivitySettings.class);
			startActivity(nextScreen);
			return true;
		}
		if (id == R.id.menuitem_manual) {
			Intent nextScreen = new Intent(getApplicationContext(), ActivityManu.class);
			startActivity(nextScreen);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
