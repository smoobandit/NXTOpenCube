package com.example.firstapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ToggleButton;

public class ActivityManu extends Activity {
	ProgressDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_manual);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
		findViewById(R.id.toggleButtonNS).setOnClickListener(onClickListenerToggle);
		findViewById(R.id.toggleButtonEW).setOnClickListener(onClickListenerToggle);
		findViewById(R.id.toggleButtonN).setOnClickListener(onClickListenerToggle);
		findViewById(R.id.toggleButtonS).setOnClickListener(onClickListenerToggle);
		findViewById(R.id.toggleButtonE).setOnClickListener(onClickListenerToggle);
		findViewById(R.id.toggleButtonW).setOnClickListener(onClickListenerToggle);
		
		
		findViewById(R.id.buttonOpen).setOnClickListener(onClickListenerGripper);
		findViewById(R.id.buttonClose).setOnClickListener(onClickListenerGripper);
		findViewById(R.id.buttonMinusEins).setOnClickListener(onClickListenerGripper);
		findViewById(R.id.buttonEins).setOnClickListener(onClickListenerGripper);
		findViewById(R.id.buttonMinusZwei).setOnClickListener(onClickListenerGripper);
		findViewById(R.id.buttonZwei).setOnClickListener(onClickListenerGripper);
		
		findViewById(R.id.buttonLifterInit).setOnClickListener(onClickListenerLifter);
		findViewById(R.id.buttonLifterMinusEins).setOnClickListener(onClickListenerLifter);
		findViewById(R.id.buttonLifterPlusEins).setOnClickListener(onClickListenerLifter);
		//findViewById(R.id.buttonLifterMinusVierzehn).setOnClickListener(onClickListenerLifter);
		//findViewById(R.id.buttonLifterMinusZehn).setOnClickListener(onClickListenerLifter);
		findViewById(R.id.buttonLifterPlusZehn).setOnClickListener(onClickListenerLifter);
		findViewById(R.id.buttonLifterPlusVierzehn).setOnClickListener(onClickListenerLifter);
		findViewById(R.id.buttonLifterMinusZwoelf).setOnClickListener(onClickListenerLifter);
	}
	
	private OnClickListener onClickListenerToggle = new OnClickListener() {
		
		@Override
        public void onClick(View view) {
			ToggleButton button = (ToggleButton) findViewById(view.getId());
			
			ToggleButton tbNS = (ToggleButton) findViewById(R.id.toggleButtonNS);
			ToggleButton tbEW = (ToggleButton) findViewById(R.id.toggleButtonEW);
			ToggleButton tbN = (ToggleButton) findViewById(R.id.toggleButtonN);
			ToggleButton tbS = (ToggleButton) findViewById(R.id.toggleButtonS);
			ToggleButton tbE = (ToggleButton) findViewById(R.id.toggleButtonE);
			ToggleButton tbW = (ToggleButton) findViewById(R.id.toggleButtonW);
			
			if (view.getId() == R.id.toggleButtonNS && button.isChecked()) { tbN.setChecked(false); tbS.setChecked(false); }
			if (view.getId() == R.id.toggleButtonEW && button.isChecked()) { tbE.setChecked(false); tbW.setChecked(false); }
			if (view.getId() == R.id.toggleButtonN && button.isChecked()) { tbNS.setChecked(false); }
			if (view.getId() == R.id.toggleButtonS && button.isChecked()) { tbNS.setChecked(false); }
			if (view.getId() == R.id.toggleButtonE && button.isChecked()) { tbEW.setChecked(false); }
			if (view.getId() == R.id.toggleButtonW && button.isChecked()) { tbEW.setChecked(false); }
		}
	};
	
	private OnClickListener onClickListenerGripper = new OnClickListener() {
		
		@Override
        public void onClick(View view) {
			Button button = (Button) findViewById(view.getId());
			String text, invtext;
			ToggleButton tbNS = (ToggleButton) findViewById(R.id.toggleButtonNS);
			ToggleButton tbEW = (ToggleButton) findViewById(R.id.toggleButtonEW);
			ToggleButton tbN = (ToggleButton) findViewById(R.id.toggleButtonN);
			ToggleButton tbS = (ToggleButton) findViewById(R.id.toggleButtonS);
			ToggleButton tbE = (ToggleButton) findViewById(R.id.toggleButtonE);
			ToggleButton tbW = (ToggleButton) findViewById(R.id.toggleButtonW);
			
			if (button.getTag().equals("OPEN") || button.getTag().equals("CLOSE")) {
				if (tbNS.isChecked()) {
					NxtMain.connNxtSM1.sendCommand(button.getTag().toString() + "(NS,1,1)");
					NxtMain.connNxtSM2.sendCommand(button.getTag().toString() + "(NS,1,1)");
				} 
				if (tbEW.isChecked()) {
					NxtMain.connNxtSM1.sendCommand(button.getTag().toString() + "(EW,1,1)");
					NxtMain.connNxtSM2.sendCommand(button.getTag().toString() + "(EW,1,1)");
				}
				if (tbN.isChecked() || tbS.isChecked()) {
					NxtMain.connNxtSM1.sendCommand(button.getTag().toString() + "(NS," + (tbN.isChecked() ? "1" : "0") + "," + (tbS.isChecked() ? "1" : "0") + ")");
					NxtMain.connNxtSM2.sendCommand(button.getTag().toString() + "(NS," + (tbN.isChecked() ? "1" : "0") + "," + (tbS.isChecked() ? "1" : "0") + ")");	
				}
				if (tbE.isChecked() || tbW.isChecked()) {
					NxtMain.connNxtSM1.sendCommand(button.getTag().toString() + "(EW," + (tbE.isChecked() ? "1" : "0") + "," + (tbW.isChecked() ? "1" : "0") + ")");
					NxtMain.connNxtSM2.sendCommand(button.getTag().toString() + "(EW," + (tbE.isChecked() ? "1" : "0") + "," + (tbW.isChecked() ? "1" : "0") + ")");	
				} 
			} else {
				text = button.getTag().toString();
				if (text.length() == 2) { invtext = text.substring(1); } else  { invtext = "-" + text; }
				if (tbNS.isChecked()) { NxtMain.connNxtSM2.sendCommand("TURN(NS," + text + "," + invtext + ")"); } 
				if (tbEW.isChecked()) { NxtMain.connNxtSM1.sendCommand("TURN(EW," + text + "," + invtext + ")"); } 
				if (tbN.isChecked() || tbS.isChecked()) { 
					NxtMain.connNxtSM2.sendCommand("TURN(NS," + (tbN.isChecked() ? text : "0") + "," + (tbS.isChecked() ? text : "0") + ")"); 
				} 
				if (tbE.isChecked() || tbW.isChecked()) { 
					NxtMain.connNxtSM1.sendCommand("TURN(EW," + (tbE.isChecked() ? text : "0") + "," + (tbW.isChecked() ? text : "0") + ")"); 
				}  
			}
	   	}
	};
	
	private OnClickListener onClickListenerLifter = new OnClickListener() {
		
		@Override
        public void onClick(View view) {
			Button button = (Button) findViewById(view.getId());
			String text = button.getTag().toString();;
			NxtMain.connNxtSM1.sendCommand(text);
		}
	};
}
