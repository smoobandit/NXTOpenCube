package com.example.firstapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class ActivityInit extends Activity {
	ProgressDialog dialog;
	final Context context = this;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		NxtMain.nxtBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (NxtMain.nxtBluetoothAdapter == null) {
			Toast.makeText(getApplicationContext(), getString(R.string.toast_nobluetooth), Toast.LENGTH_LONG).show();
		}

		if (!NxtMain.nxtBluetoothAdapter.isEnabled()) {
			Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
			int requestBt = 0;
			startActivityForResult(enableBtIntent, requestBt);
		}
		setContentView(R.layout.activity_init);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
		final Button buttonInitConnection = (Button) findViewById(R.id.buttonInitConnection);
		final Button buttonInitStart = (Button) findViewById(R.id.buttonInitStart);
		final Button buttonInitStop = (Button) findViewById(R.id.buttonInitStop);
		final Button buttonInitLifter = (Button) findViewById(R.id.buttonInitLifter);
		
		buttonInitStart.setEnabled(NxtMain.connectionEstablished);
		buttonInitStop.setEnabled(NxtMain.connectionEstablished);
		buttonInitLifter.setEnabled(NxtMain.connectionEstablished);
		
		buttonInitConnection.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		   			   		
		   	//bluetooth connection
	   		dialog = new ProgressDialog(context);
			dialog.setTitle(getString(R.string.dialog_bluetoothtitle));
	   		dialog.setMessage(getString(R.string.dialog_bluetooth));
	   		dialog.setIndeterminate(true);
	   		dialog.setCancelable(false);
	   		dialog.show();	
		   		
	   		new Thread(new Runnable() {
	   			public void run() {
	   				NxtMain.pairedDevices = NxtMain.nxtBluetoothAdapter.getBondedDevices();
			    	for (BluetoothDevice device : NxtMain.pairedDevices) {
		    			if (device.getName().equals(NxtMain.nxtName1)) NxtMain.nxtSM1 = device;
		    			if (device.getName().equals(NxtMain.nxtName2)) NxtMain.nxtSM2 = device;
		    		}

		  		 	if (NxtMain.nxtSM1 != null && NxtMain.nxtSM2 != null) {
		  				NxtMain.connNxtSM1 = new NxtConnectBluetooth(NxtMain.nxtSM1);
		    			NxtMain.connNxtSM1.start();
		    			NxtMain.connNxtSM2 = new NxtConnectBluetooth(NxtMain.nxtSM2);
		    			NxtMain.connNxtSM2.start();
		    			int i = 0;
		    			while(!NxtMain.connNxtSM1.connectionEstablished) {
		    				try{ Thread.sleep(80);
		    				} catch(InterruptedException sleepException){ }
		    				
		    				i++; if (i==100) break;
		    			}
		    			i = 0;
		    			while(!NxtMain.connNxtSM2.connectionEstablished) {
		    				try{ Thread.sleep(80);
		    				} catch(InterruptedException sleepException){ }
		    				
		    				i++; if (i==100) break;
		    			}
		    			
		    			dialog.dismiss();
		    			runOnUiThread(new Runnable() {
		    				@Override
		    				public void run() {
		    					if (NxtMain.connNxtSM1.connectionEstablished && NxtMain.connNxtSM2.connectionEstablished) {
				    				NxtMain.connectionEstablished = true;
				    				
				    				buttonInitStart.setEnabled(true);
				    				buttonInitStop.setEnabled(true);
				    				buttonInitLifter.setEnabled(true);
				    				Toast.makeText(getApplicationContext(),  getString(R.string.toast_connection), Toast.LENGTH_SHORT).show();
				    			} else {
		    						NxtMain.connectionEstablished = false;
		    						NxtMain.connNxtSM1.cancel();
				    				NxtMain.connNxtSM2.cancel();
				    				
				    				buttonInitStart.setEnabled(false);
				    				buttonInitStop.setEnabled(false);
				    				buttonInitLifter.setEnabled(false);
				    				//dialogbox
				    				AlertDialog.Builder alertDialogBuilder1 = new AlertDialog.Builder(context);
				    				alertDialogBuilder1
				    					.setTitle(getString(R.string.dialog_bluetoothtitle))
					    				.setMessage(getString(R.string.dialog_bluetoothnoconn))
					    				.setCancelable(false)
					    				.setPositiveButton("OK",new DialogInterface.OnClickListener() {
						    				public void onClick(DialogInterface dialog,int id) { dialog.cancel(); }
						    			});
				    				AlertDialog alert1 = alertDialogBuilder1.create();
				    				alert1.show();
				    			}
		    				}
		    			});
		    			
		       		} else {
		       			dialog.dismiss();
		       			runOnUiThread(new Runnable() {
		    				@Override
		    				public void run() {
		       					AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(context);
			    				alertDialogBuilder2
			    					.setTitle(getString(R.string.dialog_bluetoothtitle))
				    				.setMessage(getString(R.string.dialog_bluetoothproblem))
				    				.setCancelable(false)
				    				.setPositiveButton("OK",new DialogInterface.OnClickListener() {
					    				public void onClick(DialogInterface dialog,int id) { dialog.cancel(); }
					    			});
			    				AlertDialog alert2 = alertDialogBuilder2.create();
			    				alert2.show();
		    				}
		    			});
		       		}
		 		}
	   		}).start();
		   		
		   
		   	}
		});
		
		buttonInitStart.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		  		String text = NxtMain.progName + ".rxe";
		   		NxtMain.connNxtSM1.startProgram(text);
	   			NxtMain.connNxtSM2.startProgram(text);
		   		Toast.makeText(getApplicationContext(), "Programme " + text + " gestartet.", Toast.LENGTH_SHORT).show();
		   	}
		});
		
		buttonInitStop.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		   		NxtMain.connNxtSM1.stopProgram();
	   			NxtMain.connNxtSM2.stopProgram();
		   		Toast.makeText(getApplicationContext(), "Programme gestoppt.", Toast.LENGTH_SHORT).show();
		   	}
		});
		
		buttonInitLifter.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		   		NxtMain.connNxtSM1.sendCommand("LIFTERINIT()");
		   		NxtMain.lifterStatus = 1;
		   		Toast.makeText(getApplicationContext(), "Lifter initialisiert.", Toast.LENGTH_SHORT).show();
		   	}
		});
	}
}
