package com.example.firstapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ActivitySettings extends Activity {
	ProgressDialog dialog;
	final Context context = this;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_settings);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
   		EditText editTextNxt1 = (EditText) findViewById(R.id.editTextNxt1);
	    editTextNxt1.setText(NxtMain.nxtName1);
	   	EditText editTextNxt2 = (EditText) findViewById(R.id.editTextNxt2);
	   	editTextNxt2.setText(NxtMain.nxtName2);
   		EditText editTextProgname = (EditText) findViewById(R.id.editTextProgname);
   		editTextProgname.setText(NxtMain.progName);
   		EditText editTextWaitOpen = (EditText) findViewById(R.id.editTextWaitOpen);
   		editTextWaitOpen.setText(NxtMain.waitOpen + "");
   		EditText editTextWaitClose = (EditText) findViewById(R.id.editTextWaitClose);
   		editTextWaitClose.setText(NxtMain.waitClose + "");
   		EditText editTextWaitTurn = (EditText) findViewById(R.id.editTextWaitTurn);
   		editTextWaitTurn.setText(NxtMain.waitTurn + "");
   		EditText editTextWaitDoubleTurn = (EditText) findViewById(R.id.editTextWaitDoubleTurn);
   		editTextWaitDoubleTurn.setText(NxtMain.waitDoubleTurn + "");
   		
		Button buttonInitSave = (Button) findViewById(R.id.buttonSettingsSave);
		buttonInitSave.setOnClickListener(new OnClickListener() {
		   	@Override
	        public void onClick(View view) {
		   		EditText editTextNxt1 = (EditText) findViewById(R.id.editTextNxt1);
   		   		NxtMain.nxtName1 = editTextNxt1.getText() + "";
   		   		EditText editTextNxt2 = (EditText) findViewById(R.id.editTextNxt2);
   		   		NxtMain.nxtName2 = editTextNxt2.getText() + "";
		   		EditText editTextProgname = (EditText) findViewById(R.id.editTextProgname);
		   		NxtMain.progName = editTextProgname.getText() + "";
		   		EditText editTextWaitOpen = (EditText) findViewById(R.id.editTextWaitOpen);
		   		NxtMain.waitOpen = Integer.parseInt(editTextWaitOpen.getText() + "");
		   		EditText editTextWaitClose = (EditText) findViewById(R.id.editTextWaitClose);
		   		NxtMain.waitClose = Integer.parseInt(editTextWaitClose.getText() + "");
		   		EditText editTextWaitTurn = (EditText) findViewById(R.id.editTextWaitTurn);
		   		NxtMain.waitTurn = Integer.parseInt(editTextWaitTurn.getText() + "");
		   		EditText editTextWaitDoubleTurn = (EditText) findViewById(R.id.editTextWaitDoubleTurn);
		   		NxtMain.waitDoubleTurn = Integer.parseInt(editTextWaitDoubleTurn.getText() + "");
		   		SharedPreferences settings = getSharedPreferences("Settings", 0);
		   		SharedPreferences.Editor editor = settings.edit();
				editor.putString("NxtName1",NxtMain.nxtName1);
				editor.putString("NxtName2",NxtMain.nxtName2);
				editor.putString("ProgName",NxtMain.progName);
				editor.putString("WaitOpen",NxtMain.waitOpen + "");
				editor.putString("WaitClose",NxtMain.waitClose + "");
				editor.putString("WaitTurn",NxtMain.waitTurn + "");
				editor.putString("WaitDoubleTurn",NxtMain.waitDoubleTurn + "");
				editor.commit();	   		
		   	}
		});
	}
}
