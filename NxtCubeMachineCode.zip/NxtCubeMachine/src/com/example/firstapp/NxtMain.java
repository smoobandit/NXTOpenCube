package com.example.firstapp;

import java.util.Set;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

public class NxtMain {
	public static BluetoothAdapter nxtBluetoothAdapter;
	public static Set<BluetoothDevice> pairedDevices;
	
	public static NxtConnectBluetooth connNxtSM1;
	public static NxtConnectBluetooth connNxtSM2;
	public static BluetoothDevice nxtSM1;
	public static BluetoothDevice nxtSM2;
	
	public static boolean connectionEstablished = false;
	public static boolean stop = false;
	
	public static long starttime = 0;
	public static boolean runtime = false;
	
	public static String picpath = "/sdcard/";
	
	public static int lifterStatus = 0;
	public static String nxtName1;
	public static String nxtName2;
	public static String progName;
	
	public static int waitOpen;
	public static int waitClose;
	public static int waitTurn;
	public static int waitDoubleTurn;
	
	public static String cubeDefinition;
	public static String cubeSolve;
}
