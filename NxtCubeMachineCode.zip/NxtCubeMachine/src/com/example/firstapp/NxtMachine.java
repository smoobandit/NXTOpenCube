package com.example.firstapp;

public class NxtMachine {
	
	public NxtAxis[] axes = new NxtAxis[2];  /*0: NORTH-SOUTH, 1: EAST-WEST*/
	
	private char upside;
	private char downside; 
	
	//axes[0].side[0] = 'N';
	
	public NxtMachine () {
		upside = 'U';
		downside = 'D';
		axes[0] = new NxtAxis(this,"NS");
		axes[0].setSide(0, 'F'); //N 
		axes[0].setSide(1, 'B'); //S
		axes[1] = new NxtAxis(this,"EW");
		axes[1].setSide(0, 'L'); //E
		axes[1].setSide(1, 'R'); //W
  	}

	public NxtAxis getAxis(int index) { return this.axes[index]; }
	
	private char getSideFromMove(String move) { return move.charAt(0); }
	
	private int getTurnFromMove(String move) { 
		int a;
		a = 0;
		if (move.length() == 1) { 
			a = 1; 
		} else {
			if (move.charAt(1) == '2') { a = 2; } else { a = -1; }
		}
		return a; 
	}
	
	void moveCube(String movestring) {
		String moves[] = movestring.split("\\s+");
		
		/*
		if (movestring.contains(" ")) {
			String moves[] = movestring.split(" ");
		} else {
			String moves[] = {movestring};
		}
		*/
		int im = 0;
		char side;
		int ta, tq, fa, fq, ma, mq;
		boolean cw;
		char us, ds;
		int a, b;
		char s;
		
		while (im < moves.length) {
			side = getSideFromMove(moves[im]);
			if (upside == side || downside == side) {
				//rotate
				ta = (Math.random() > 0.5) ? 0 : 1;
				tq = ta == 1 ? 0 : 1;
				if (axes[ta].isFixed()) { fa = ta; fq = tq; } else { fa = tq; fq = ta; }
				this.axes[fq].makeOpen();
				this.axes[fq].makeVertical();
				cw = (Math.random() > 0.5);
				//cw = true;
				this.axes[fa].makeTurn(cw ? 1 : -1, cw ? -1 : 1);
				this.axes[fq].makeClose();
				
				//update sides
			 	us = upside;
				ds = downside;
				upside = axes[fq].getSide((cw && fa == 0 || !cw && fa == 1) ? 0 : 1); 
				downside = axes[fq].getSide((!cw && fa == 0 || cw && fa == 1) ? 0 : 1);
				axes[fq].setSide((cw && fa == 0 || !cw && fa == 1) ? 0 : 1, ds); 
				axes[fq].setSide((!cw && fa == 0 || cw && fa == 1) ? 0 : 1, us); 
			}
			a = getTurnFromMove(moves[im]); 
			b = 0;
			im++;
			if (im < moves.length) {
				s = getSideFromMove(moves[im]);
				if (side == 'R' &&  s == 'L' || side == 'L' &&  s == 'R' || side == 'U' &&  s == 'D' || side == 'D' &&  s == 'U' || side == 'F' &&  s == 'B' || side == 'B' &&  s == 'F') {
					//doublemove
					b = getTurnFromMove(moves[im]);
					im++;
				}
			}
			if (axes[0].getSide(0) == side || axes[0].getSide(1) == side) { ma = 0; mq = 1; } else { ma = 1; mq = 0; }
			axes[mq].makeFixe();
			if (axes[ma].getSide(0) == side) { axes[ma].makeTurn(a, b); } else { axes[ma].makeTurn(b, a); }
		}
		axes[0].makeFixe();
		axes[1].makeFixe();
	}
}
