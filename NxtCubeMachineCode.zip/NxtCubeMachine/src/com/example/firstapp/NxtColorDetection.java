package com.example.firstapp;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Color;

public class NxtColorDetection {
	private int[] xstart = { 535, 770,1075, 820,1125,1500,1150,1530,1980};
	private int[] ystart = {1370, 940, 425,1825,1430, 900,2320,1990,1480};
	
	private int[][][] colors = new int[6][9][3];
	private int[][][] distance = new int [6][9][6];
	
	//var cub = "UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB";
	private char[] sides = {'U','R','F','D','L','B'};
	private int[][] order = {
								{8, 7, 6, 5, 4, 3, 2, 1, 0}, //U
								{6, 3, 0, 7, 4, 1, 8, 5, 2}, //R
								{6, 3, 0, 7, 4, 1, 8, 5, 2}, //F
								{0, 1, 2, 3, 4, 5, 6, 7, 8}, //D
								{6, 3, 0, 7, 4, 1, 8, 5, 2}, //L
								{6, 3, 0, 7, 4, 1, 8, 5, 2}  //B
							};
	private char[][] cubetemp = new char[6][9];
	private String[] farbe = {"Yellow","Orange","Green","White","Red","Blue"};
	
	
	public String getCube(String path, boolean detectionfile) {
		String retval;
		Bitmap bitmap;
		String text;
		int pixel, r, g, b;
		int[] rgb = new int[3];
		int count;
		int dist;
		int index;
		int samplesize = 4;
		int ucnt, rcnt, fcnt, dcnt, lcnt, bcnt;
		String f;
		
		final BitmapFactory.Options options = new BitmapFactory.Options();
		options.inSampleSize = samplesize;
		options.inPreferredConfig = Config.RGB_565;
		
		for (int i = 0; i < 6; i++){
			bitmap = BitmapFactory.decodeFile(path + sides[i] + ".jpg", options);
			for (int j = 0; j < 9; j++) {
				count = 0; 
				r = 0; g = 0; b = 0;
				for (int x = (int) ((xstart[j] - 50) / samplesize) ; x < (int) ((xstart[j] + 50) / samplesize); x++) {
					for (int y = (int) ((ystart[j] - 50) / samplesize); y < (int) ((ystart[j] + 50) / samplesize); y++) {
						count++;
						pixel = bitmap.getPixel(x, y);
						r += Color.red(pixel);
						g += Color.green(pixel);
						b += Color.blue(pixel);  
					}
				 }
				 rgb = normalize(r/count, g/count, b/count);
				 colors[i][j][0] = rgb[0]; colors[i][j][1] = rgb[1]; colors[i][j][2] = rgb[2];
			}
			if(bitmap!=null) { bitmap.recycle(); bitmap = null; }
		}
		 
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 9; j++) {
				for (int k = 0; k < 6; k++) {
					distance[i][j][k] = getDistance(colors[i][j][0], colors[i][j][1], colors[i][j][2], colors[k][4][0], colors[k][4][1], colors[k][4][2]); 
				}
			}
		}
		
		for (int i = 0; i < 6; i++) {
			farbe[i] = getColor(colors[i][4][0], colors[i][4][1], colors[i][4][2]);
		}
		
		text = "First Iteration:\r\n";
		for (int i = 0; i < 6; i++) {
			 text += sides[i] + "\r\n";
			 for (int j = 0; j < 9; j++) { 
				 text += j + ":" +" R: " + String.format("%03d", colors[i][j][0]) + ", G: " + String.format("%03d", colors[i][j][1]) + ", B: " + String.format("%03d", colors[i][j][2]) + " = ";
				 dist = 300; index = 0;
				 for (int k = 0; k < 6; k++) {
					 if (distance[i][j][k] < dist) { dist = distance[i][j][k]; index = k;}
					 //text += sides[l] + "=" + distance[i * 9 + j][l] + " ";
				 }
				 text += sides[index] + " (" + farbe[index] + ")\r\n";
				 cubetemp[i][j] = sides[index];
			 }
			 text += "\r\n";
		}
		
		ucnt = 0; rcnt = 0; fcnt = 0; dcnt = 0; lcnt = 0; bcnt = 0;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 9; j++) {
				switch(cubetemp[i][j]) {
					case 'U': ucnt++; break;
					case 'R': rcnt++; break;
					case 'F': fcnt++; break;
					case 'D': dcnt++; break;
					case 'L': lcnt++; break;
					case 'B': bcnt++; break;
				}
			}
		}
		
		if (ucnt != 9 || rcnt != 9 || fcnt != 9 || dcnt != 9 || lcnt != 9 || bcnt != 9) {
			text += "Second Iteration:\r\n";
			for (int i = 0; i < 6; i++) {
				text += sides[i] + "\r\n";
				for (int j = 0; j < 9; j++) {
					text += j + ":" +" R: " + String.format("%03d", colors[i][j][0]) + ", G: " + String.format("%03d", colors[i][j][1]) + ", B: " + String.format("%03d", colors[i][j][2]) + " = ";
					f = getColor(colors[i][j][0], colors[i][j][1], colors[i][j][2]);
					for (int k = 0; k < 6; k++) {
						if (f == farbe[k]) { 
							cubetemp[i][j] = sides[k]; 
							text += sides[k] + " (" + farbe[k] + ")\r\n";
						}
					}
				}
				text += "\r\n";
			}
		}
		
		retval = "";
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 9; j++) {
				retval += cubetemp[i][order[i][j]];
			}
		}
		text += "Cube Definition String:\r\n";
		for (int i = 0; i < 6; i++) {
			text += sides[i] + ": " + retval.substring(i * 9, i* 9 + 9) + "\r\n";
		}
				
		if (detectionfile) {
			FileOutputStream outStream = null;
			try {
				 outStream = new FileOutputStream(path + "detectionfile.txt");
				 outStream.write(text.getBytes());
				 outStream.close();
			} catch (FileNotFoundException e) {
					e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {}
		}
		return retval;
	}
	
	private String getColor (int r, int g, int b) {
		String retval = "---";
		if (r < 10 && g > 15 && g < 95 && b > 99) { retval = "Blue"; }
		if (r > 50 && g > 99 && b < 10) { retval = "Yellow"; }
		if (r < 10 && g > 99 && b < 80) { retval = "Green"; }
		if (r > 99 && g > 10 && b < 10) { retval = "Orange"; }
		if (r > 99 && g < 10 && b < 90) { retval = "Red"; }
		if (r > 20 && g > 20 && b > 99) { retval = "White"; }
		return retval;
	}
	
	private int getDistance (int r1, int g1, int b1, int r2, int g2, int b2) {
		int retval;
		retval = (int) (Math.abs(r1 - r2) + Math.abs(g1 - g2) + Math.abs(b1 - b2)); 
		if (r1 == r2) { retval = retval/2; }
		if (g1 == g2) { retval = retval/2;}
		if (b1 == b2) { retval = retval/2;}
		if (r2 == 0 && r1 > 5) { retval = retval * 2;}
		if (g2 == 0 && g1 > 5) { retval = retval * 2;}
		if (b2 == 0 && b1 > 5) { retval = retval * 2;}
		if (r2 == 100 && r1 < 95) { retval = retval * 2;}
		if (g2 == 100 && g1 < 95) { retval = retval * 2;}
		if (b2 == 100 && b1 < 95) { retval = retval * 2;}
		return retval;
	}
	
	private int[] normalize(int r, int g, int b) {
		int[] retval = new int[3];
		double rd = 0, gd = 0, bd = 0;
		if (r==0 && g==0 && b==0) {
			rd = 0; gd = 0; bd = 0;
		} else {
			if (r >= g && r >= b) { rd = 100; gd = g * 100/r; bd = b * 100/r; }
			if (g >= r && g >= b) { gd = 100; rd = r * 100/g; bd = b * 100/g; }
			if (b >= r && b >= g) { bd = 100; rd = r * 100/b; gd = g * 100/b; }
		}
		retval[0] = (int) rd;
	    retval[1] = (int) gd;
	    retval[2]=  (int) bd;
		return retval;
	}
}
