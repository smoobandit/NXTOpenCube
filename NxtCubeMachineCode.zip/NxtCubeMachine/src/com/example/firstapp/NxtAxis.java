package com.example.firstapp;

public class NxtAxis {
	NxtMachine machine;	//parent object
	
	private String direction; 			//NS, EW 	
	private char side[] = new char[2]; 	//U,D,L,R,F,B
	private int align[] = new int[2]; 	//0: vertical, 1: horizontal
	private int status[] = new int[2]; 	//0: closed, 1: opened

	public NxtAxis(NxtMachine machinevalue, String dirvalue)
  	{
		this.machine = machinevalue;	
		this.direction = dirvalue;
		align[0] = 0; align[1] = 0;
		status[0] = 0; align[1] = 0;
  	}
	
	char getSide(int index) {
		return side[index];
	}
	
	void setSide(int index, char sideval) {
		side[index] = sideval;
	}
	
	String getDirection() {
		return this.direction;
	}	
	
	boolean isFixed () {
		return (this.align[0] == 0 && this.align[1] == 0 && this.status[0] == 0 && this.status[1] == 0);
	}

	void makeFixe() {
		if (isFixed()) { return; }
		if (align[0] == 1 && align[1] == 1) {
			makeOpen();
			makeVertical();
		} else {
			if (align[0] == 1 && align[1] == 0) { 
				if (status[0] == 0) { this.open(1, 0); status[0] = 1; } 
				this.turn(Math.random() > 0.5 ? 1 : -1, 0); 
				align[0] = 0; 
			}
			if (align[0] == 0 && align[1] == 1) { 
				if (status[1] == 0) { this.open(0, 1); status[1] = 1; } 
				this.turn(0, Math.random() > 0.5 ? 1 : -1); 
				align[1] = 0;
			}
		}
		makeClose();
	}
	void makeOpen() {
		this.open(this.status[0] == 0 ? 1 : 0, this.status[1] == 0 ? 1 : 0 );
		this.status[0] = 1; this.status[1] = 1;
	}

	void makeClose() {
		this.close(this.status[0] == 1 ? 1 : 0, this.status[1] == 1 ? 1 : 0 );
		this.status[0] = 0; this.status[1] = 0;
	}

	void makeVertical() {
		int a, b;	
		if (align[0] == 1) { a = Math.random() < 0.5 ? 1 : -1; }	else { a = 0; }
		if (align[1] == 1) { b = Math.random() < 0.5 ? 1 : -1; }	else { b = 0; }
		this.turn(a, b);
		this.align[0] = 0; this.align[1] = 0;
	}

	void makeTurn(int turna, int turnb) {
		this.turn(turna, turnb);
		if (turna == 1 || turna == -1) { this.align[0] = this.align[0] == 0 ? 1 : 0; }
		if (turnb == 1 || turnb == -1) { this.align[1] = this.align[1] == 0 ? 1 : 0; }
	}

	private void open (int a, int b) {
		NxtMain.connNxtSM1.sendCommand("OPEN(" + direction + "," + Integer.toString(a) + "," + Integer.toString(b) + ")");
	}
	
	private void close (int a, int b) {
		NxtMain.connNxtSM1.sendCommand("CLOSE(" + direction + "," + Integer.toString(a) + "," + Integer.toString(b) + ")");
	}
	
	private void turn (int a, int b) {
		String text;
		text = "TURN(" + direction + "," + Integer.toString(a) + "," + Integer.toString(b) + ")";
		if (direction.equals("NS")) { NxtMain.connNxtSM2.sendCommand(text); }
		if (direction.equals("EW")) { NxtMain.connNxtSM1.sendCommand(text); }
	}
}

