package com.example.firstapp;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.UUID;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

public class NxtConnectBluetooth extends Thread {
	
	public BluetoothSocket nxtSocket;
	private OutputStream nxtOutputStream;
	private InputStream nxtInputStream;
	
	private UUID myUUID;

	public boolean connectionEstablished;
	public boolean messageReceived;
	public String nxtMessage;
	
	/* create bluetooth socket with given UUID */
    public NxtConnectBluetooth(BluetoothDevice device) {
    	this.connectionEstablished = false;
        myUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        try {
    		nxtSocket = device.createRfcommSocketToServiceRecord(myUUID);
    	} catch (IOException socketException) { }
    }

    /* try to establish a connection through the socket and get OutputStream */
    public void run() {
    	try {
    		nxtSocket.connect();
    		this.connectionEstablished = true;
    	} catch (IOException connectException) { }
    	
    	try {
    		nxtOutputStream = new DataOutputStream(nxtSocket.getOutputStream());
    	} catch (IOException streamException) { }
    	
    	
    }

    /* close the socket and end the connection */
    public void cancel() {
    	try {
    		nxtSocket.close();
    		this.connectionEstablished = false;
       	} catch (IOException closeException) { }
    }
    
    
    public boolean startProgram(String text) {
    	boolean retval = false;
    	ByteBuffer buffer;
    	int byteslength = text.length();
    	
    	buffer = ByteBuffer.allocate(byteslength + 8); 		
    	buffer.order(ByteOrder.LITTLE_ENDIAN); 	
    	buffer.putShort((short) (byteslength + 6)); 		
    	buffer.put((byte) 0x80); 		
    	buffer.put((byte) 0x00); 			
    			
    	for (char c : text.toCharArray()) {buffer.put((byte) c);}
		
    	buffer.put((byte) 0x00); 	
		
		try {
		   nxtOutputStream.write(buffer.array());
		   retval = true;
		} catch (IOException writeException) {
		   cancel();
		}
    	return retval;
    }
    
    public boolean stopProgram() {
    	boolean retval = false;
    	ByteBuffer buffer;
    	
    	buffer = ByteBuffer.allocate(8); 		
    	buffer.order(ByteOrder.LITTLE_ENDIAN); 	
    	buffer.putShort((short) (6)); 		
    	buffer.put((byte) 0x80); 		
    	buffer.put((byte) 0x01); 			
    	buffer.put((byte) 0x00); 	
		
		try {
		   nxtOutputStream.write(buffer.array());
		   retval = true;
		} catch (IOException writeException) {
		   cancel();
		}
    	return retval;
    }
    
    public boolean sendCommand(String text) {
    	boolean retval = false;
    	ByteBuffer buffer;
    	int msgbox = 1;
    	int i;
    	int byteslength = text.length();
    	byte[] readbuffer = new byte[1024];
		int bytes = 0;
    	
		if (NxtMain.stop) { return retval; }
		
		nxtInputStream = null;
		try {
			nxtInputStream = nxtSocket.getInputStream();
		} catch (IOException e) {
			cancel();
		}
		
		try {
			if (nxtInputStream.available() > 0) {
				try {
					bytes = nxtInputStream.read(readbuffer);
				} catch (IOException e) {
					// ERROR
				}			
			}
		} catch (IOException e) { }
    	
    	buffer = ByteBuffer.allocate(byteslength + 10); 		
    	buffer.order(ByteOrder.LITTLE_ENDIAN); 	
    	buffer.putShort((short) (byteslength + 8)); 		
    	buffer.put((byte) 0x80); 		
    	buffer.put((byte) 0x09); 			
    	buffer.put((byte) (msgbox - 1)); 				
    	buffer.put((byte) (byteslength +1)); 				
		for (char c : text.toCharArray()) {buffer.put((byte) c);}
		buffer.put((byte) 0x00); 	
		try {
		   nxtOutputStream.write(buffer.array());
		} catch (IOException writeException) {
		   cancel();
		}
				
		nxtInputStream = null;
		try {
			nxtInputStream = nxtSocket.getInputStream();
		} catch (IOException e) {
			cancel();
		}
		
		i = 0;
		try {
			while( nxtInputStream.available() == 0) {
				try{ Thread.sleep(50);
				} catch(InterruptedException sleepException){ }
				i++; if (i==300) break;
			}
		} catch (IOException e) { }
		
		try {
			if (nxtInputStream.available() > 0) {
				try {
					bytes = nxtInputStream.read(readbuffer);
				} catch (IOException e) {
					cancel();
				}
				String readMessage = new String(readbuffer, 0, bytes);
				if (readMessage.substring(6).equals("OK")) { retval = true;}
			}
		} catch (IOException e) { }
		
		
		return retval;
	}
}
	
	
	